export const DARK_MODE_LOCAL_STORAGE_KEY = "mode";
export const LOGIN_LOCAL_STORAGE_KEY = "isLoggedIn";
export const USERNAME_LOCAL_STORAGE_KEY = "username";
export const FAVOURITES_LOCAL_STORAGE_KEY = "my-favourites";
