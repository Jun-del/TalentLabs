// Images from https://pixabay.com/images/search/food/
const images = [
  {
    title: "Steak",
    url: "https://cdn.pixabay.com/photo/2017/01/26/02/06/platter-2009590_1280.jpg",
  },
  {
    title: "Lunch",
    url: "https://cdn.pixabay.com/photo/2015/11/19/10/38/food-1050813_1280.jpg",
  },
  {
    title: "Chef preparing food",
    url: "https://cdn.pixabay.com/photo/2016/03/27/21/34/restaurant-1284351_1280.jpg",
  },
  {
    title: "Breakfast",
    url: "https://cdn.pixabay.com/photo/2016/11/18/14/39/beans-1834984_1280.jpg",
  },
  {
    title: "Pizza",
    url: "https://cdn.pixabay.com/photo/2017/09/30/15/10/plate-2802332_1280.jpg",
  },
];

export default images;
