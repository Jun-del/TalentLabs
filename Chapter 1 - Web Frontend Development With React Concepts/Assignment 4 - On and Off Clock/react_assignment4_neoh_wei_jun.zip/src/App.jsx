import "./App.css";
import ClockControl from "./components/ClockControl";

function App() {
	return <ClockControl />;
}

export default App;
