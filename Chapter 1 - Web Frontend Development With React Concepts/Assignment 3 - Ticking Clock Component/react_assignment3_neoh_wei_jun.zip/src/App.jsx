import "./App.css";
import Clock from "./components/Clock";

function App() {
	return <Clock />;
}

export default App;
